import React from 'react'
import "./Button.css"

const Button = () => {
    return (
        <div>
            <button type="submit">Criar Card</button>
        </div>
    )
}

export default Button